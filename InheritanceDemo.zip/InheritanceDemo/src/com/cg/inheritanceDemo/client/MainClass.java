package com.cg.inheritanceDemo.client;

import com.cg.inheritanceDemo.beans.CEmployee;
import com.cg.inheritanceDemo.beans.Developer;
import com.cg.inheritanceDemo.beans.Employee;
import com.cg.inheritanceDemo.beans.PEmployee;
import com.cg.inheritanceDemo.beans.SalesManager;

public class MainClass {

	public static void main(String[] args) {
		Employee emp;

		/*	Employee emp=new Employee(100,200000,"aanchal","srivastava");
		emp.calculateSalary();
		System.out.println(emp.getTotalSalary());

		PEmployee pemp=new PEmployee(200,100000,"abc","xyz");
		pemp.calculateSalary();
		System.out.println(pemp.getTotalSalary());

		CEmployee cemp=new CEmployee(290,10000,"aanchal","abc",20);
		cemp.calculateSalary();
		cemp.signContract();
		System.out.println(cemp.getTotalSalary());

		Developer d=new Developer(200,2000,"preeti","abc",20);
		d.calculateSalary();
		System.out.println(d.getTotalSalary());

		SalesManager sm=new SalesManager(400,9000,"madhu","abc",10);
		sm.calculateSalary();
		System.out.println(sm.getTotalSalary()); */

		emp=new  PEmployee(200,100000,"abc","xyz");
		emp.calculateSalary();
		System.out.println(emp.getTotalSalary());
		System.out.println(emp.toString());

		emp= new CEmployee(290,10000,"aanchal","abc",20);
		CEmployee cemp=(CEmployee)emp;
		emp.calculateSalary();
		cemp.signContract();
		System.out.println(emp.getTotalSalary());
		System.out.println(emp.toString());

		emp=new  Developer(200,2000,"preeti","abc",20);
		Developer d=(Developer)emp;
		d.DeveloperProject();
		emp.calculateSalary();
		System.out.println(emp.getTotalSalary());
		System.out.println(emp.toString());

		emp=new SalesManager(400,9000,"madhu","abc",10);
		emp.calculateSalary();
		System.out.println(emp.getTotalSalary()); 
		System.out.println(emp.toString());




	}

}
