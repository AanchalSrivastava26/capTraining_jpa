package com.cg.inheritanceDemo.beans;

public final class SalesManager extends PEmployee {

	private int noOfSales,commission;
	public SalesManager(int employeeId, int basicSalary, String firstName, String lastName,int noOfSales) {
		super(employeeId, basicSalary, firstName, lastName);
		this.noOfSales=noOfSales;
	}
	public int getNoOfSales() {
		return noOfSales;
	}
	public void setNoOfSales(int noOfSales) {
		this.noOfSales = noOfSales;
	}
	public int getCommission() {
		return commission;
	}
	public void setCommission(int commission) {
		this.commission = commission;
	}
	public void calculateSalary() {
		commission=noOfSales*2000;
		super.calculateSalary();
		setTotalSalary(getTotalSalary()+commission);
	}
	@Override
	public String toString() {
		return super.toString()+"noOfSales=" + noOfSales + ", commission=" + commission ;
	}



}
