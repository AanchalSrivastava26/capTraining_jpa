package com.cg.inheritanceDemo.beans;

public final class Developer extends PEmployee {
	private int noOfProjects,incentives;



	public Developer(int employeeId, int basicSalary, String firstName, String lastName,int noOfProjects) {
		super(employeeId, basicSalary, firstName, lastName);
		this.noOfProjects=noOfProjects;
	}

	public int getNoOfProjects() {
		return noOfProjects;
	}

	public void setNoOfProjects(int noOfProjects) {
		this.noOfProjects = noOfProjects;
	}

	public int getIncentives() {
		return incentives;
	}

	public void setIncentives(int incentives) {
		this.incentives = incentives;
	}
	public void DeveloperProject() {
		System.out.println("project completed");
	}

	@Override
	public void calculateSalary() {
		incentives=noOfProjects*2000;
		super.calculateSalary();
		setTotalSalary(getTotalSalary()+incentives);


	}

	@Override
	public String toString() {
		return super.toString()+"noOfProjects=" + noOfProjects + ", incentives=" + incentives;
	}







}
