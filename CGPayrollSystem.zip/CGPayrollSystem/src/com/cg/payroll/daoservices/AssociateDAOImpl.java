package com.cg.payroll.daoservices;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import com.cg.payroll.beans.Associate;


public class AssociateDAOImpl implements AssociateDAO {
	private EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("JPA-PU");

	@Override
	public Associate save(Associate associate) {																	//EntityMananger manages entities
		EntityManager entityManager=entityManagerFactory.createEntityManager();//EntityManager interface provides API for interacting with entity
		entityManager.getTransaction().begin(); //pulls the Entity transaction object and begins the transaction using begin() method
		entityManager.persist(associate);//makes an instance managed and persistent
		entityManager.getTransaction().commit();
		entityManager.close();
		return associate;
	}

	@Override
	public boolean update(Associate associate) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(associate);
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}

	@Override
	public Associate findOne(int associateId) {

		return entityManagerFactory.createEntityManager().find(Associate.class, associateId);//find(class,primary key)
	}																																								//retrieves a specific entity object

	@Override
	public List<Associate> findAll() {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		Query query=entityManager.createQuery("from Associate a");// like select* from Associate(in sql) we use from Associate where a is any alias name
		return query.getResultList();
	}


}
