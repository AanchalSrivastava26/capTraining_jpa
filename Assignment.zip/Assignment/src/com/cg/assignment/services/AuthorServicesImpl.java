package com.cg.assignment.services;

import com.cg.assignment.bean.Author;
import com.cg.assignment.dao.AuthorDao;
import com.cg.assignment.dao.AuthorDaoImpl;


public class AuthorServicesImpl implements AuthorServices{
	private AuthorDao authorDao;
	public AuthorServicesImpl() {
		authorDao=new AuthorDaoImpl();
	}

	public AuthorServicesImpl(AuthorDao authorDao) {
		super();
		this.authorDao = authorDao;
	}

	@Override
	public int acceptAuthorDetails(String firstName, String middleName, String lastName, int mobileNo) {
		Author author=new Author(mobileNo, firstName, lastName, middleName);
		author=authorDao.save(author);
			return author.getAuthorId();
	}

	@Override
	public Author getAssociateDetails(int authorId) {
	
		return null;
	}

}
