package com.cg.assignment.services;

import com.cg.assignment.bean.Author;

public interface AuthorServices {
	int acceptAuthorDetails(String firstName, String middleName,String lastName,int mobileNo);
	Author getAssociateDetails(int authorId);
}
