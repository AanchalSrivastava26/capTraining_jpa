package com.cg.assignment.dao;

import com.cg.assignment.bean.Author;

public interface AuthorDao {
	 Author save(Author author);
		boolean update(Author author);
		Author findOne(int authorId);
}
